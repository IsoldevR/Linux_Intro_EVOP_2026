#!/bin/bash 
#This script loops through the files and concatenates the output of searching for the mitogenome "MH893761" into one file
cd  mosdepth_files/
for file in *_summary.txt; 
do 
grep "MH893761.1" file > mito_depth_all.txt 
done
echo "done!"
