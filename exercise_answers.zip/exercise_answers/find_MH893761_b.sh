#!/bin/bash this is to find MH893761 in multiple lines and save it into a new file, mito_depth.txt
grep "MH893761.1" E10_*.txt | awk '{print $3/$2}' > only_mito_depth.txt
echo "done!"
