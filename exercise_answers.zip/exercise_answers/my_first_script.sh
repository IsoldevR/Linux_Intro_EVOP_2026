q#!/bin/bash 
#This is a comment to remind myself that echo is a command to print something to the terminal
echo "WOW! You start looking like a super hero!"
